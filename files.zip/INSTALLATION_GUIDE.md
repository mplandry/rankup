# 🚀 Enhanced Students Page - Installation Guide

## ✨ New Features Added

### Priority 1 (Core Features)
1. ✅ **Search & Filter** - Find students instantly by name, email, department, exam type, activity, and performance
2. ✅ **Export to CSV** - Download filtered student list with all stats
3. ✅ **Detailed Student View** - Click any student name to see full progress dashboard

### Priority 2 (Advanced Features)
4. ✅ **Email Inactive Students** - One-click re-engagement for students inactive 30+ days
5. ✅ **Bulk Operations** - Select multiple students and bulk delete
6. ✅ **Edit Student Info** - Update name, department, exam type directly from the table

---

## 📦 Files to Install

### 1. Enhanced StudentsTable Component
**File:** `StudentsTable_ENHANCED.tsx`  
**Location:** `src/components/students/StudentsTable.tsx`

**What it includes:**
- Search bar (searches name, email, department)
- 4 filter dropdowns (Exam Type, Activity, Performance, custom)
- Export to CSV button
- Email Inactive button
- Bulk delete (select multiple students)
- Edit button for each student
- Click student name to view details
- All existing features preserved

### 2. API Route - Edit Students
**File:** `api_students_[id]_route.ts`  
**Location:** `src/app/api/students/[id]/route.ts`

**What it does:**
- PATCH endpoint to update student info (name, department, exam type)
- DELETE endpoint (already exists, included for completeness)
- Admin-only access control

### 3. API Route - Email Inactive Students
**File:** `api_students_email-inactive_route.ts`  
**Location:** `src/app/api/students/email-inactive/route.ts`

**What it does:**
- Finds students inactive for 30+ days
- Sends re-engagement emails via Resend
- Returns count of emails sent

---

## 🔧 Installation Steps

### Step 1: Replace StudentsTable Component
```bash
# In your project root
cp StudentsTable_ENHANCED.tsx src/components/students/StudentsTable.tsx
```

### Step 2: Add API Routes
```bash
# Create the [id] route (if it doesn't exist, or replace existing)
mkdir -p src/app/api/students/\[id\]
cp api_students_[id]_route.ts src/app/api/students/\[id\]/route.ts

# Create email-inactive route
mkdir -p src/app/api/students/email-inactive
cp api_students_email-inactive_route.ts src/app/api/students/email-inactive/route.ts
```

### Step 3: Verify Dependencies
Make sure you have Resend installed:
```bash
npm install resend
```

Your `package.json` should already have this since you're using Resend for other emails.

### Step 4: Environment Variables
Verify these are in your `.env.local`:
```
RESEND_API_KEY=re_...
NEXT_PUBLIC_SUPABASE_URL=...
NEXT_PUBLIC_SUPABASE_ANON_KEY=...
```

### Step 5: Deploy
```bash
git add src/components/students/StudentsTable.tsx
git add src/app/api/students/\[id\]/route.ts
git add src/app/api/students/email-inactive/route.ts
git commit -m "Add enhanced Students page with search, filters, export, bulk ops, and email"
git push
```

---

## 🎯 How to Use Each Feature

### 1. Search Students
Type in the search box to filter by:
- Student name
- Email address
- Department name

### 2. Apply Filters
Use the dropdown filters to narrow down by:
- **Exam Type:** Lieutenant or Captain
- **Activity:** Active last 7/30 days, or Inactive (30+ days)
- **Performance:** Passing (≥70%), Failing (<70%), No Sessions Yet

### 3. Export to CSV
- Click "📥 Export CSV" button
- Downloads a CSV file with all visible (filtered) students
- Includes: Name, Email, Department, Exam Type, Sessions, Scores, Last Active, Created Date
- Filename: `students_export_YYYY-MM-DD.csv`

### 4. View Student Details
- Click on any student's **name** in the table
- Opens a modal with:
  - Basic info (Department, Exam Type, Last Active, Member Since)
  - Performance stats (Total Sessions, Avg Score, Best Score)
  - Question history (Total Questions, Correct/Incorrect, Last Session)

### 5. Edit Student Info
- Click **"Edit"** button for any student
- Opens a modal to update:
  - Full Name
  - Department
  - Exam Type (Lieutenant ↔ Captain)
- Click "Save Changes" to update

### 6. Email Inactive Students
- Click "📧 Email Inactive" button
- Automatically finds students inactive for 30+ days
- Sends a re-engagement email to each one
- Shows confirmation: "Sent X emails to inactive students"

### 7. Bulk Delete
- Check the checkboxes next to students you want to delete
- Or check the header checkbox to select all visible students
- Click "🗑️ Delete Selected (X)" button
- Confirms before deleting

### 8. Clear Filters
- When any filters are active, a "Clear Filters" button appears
- Click it to reset all filters and search

---

## 📧 Inactive Student Email Template

The email sent to inactive students includes:
- Personalized greeting with their name
- Reminder about upcoming exam
- List of features waiting for them
- Big "Get Back to Studying" CTA button
- Last active date (or "haven't logged in yet")

**Email subject:** "We miss you at RankUp! 🔥"

---

## 🎨 UI Highlights

### Search & Filter Bar
- Clean, organized layout
- Responsive grid (stacks on mobile)
- All filters work together (AND logic)
- Shows filtered count in Export button

### Table Enhancements
- Checkbox column for bulk selection
- Student name is clickable (opens detail modal)
- Edit and Delete buttons for each row
- Maintains all existing columns and styling

### Modal Windows
- **Detail Modal:** Full student dashboard with stats
- **Edit Modal:** Simple form with 3 fields
- Both have smooth open/close transitions
- Click outside or "×" to close

---

## 🔒 Security Notes

- All API routes check for admin role
- Only admins can view/edit/delete students
- Only admins can send emails
- Student updates are logged with `updated_at` timestamp
- Only specific fields can be updated (whitelist)

---

## 📊 Example Use Cases

1. **Find struggling students:**
   - Filter: Performance = "Failing"
   - Export CSV → Follow up with each one

2. **Re-engage inactive users:**
   - Filter: Activity = "Inactive (30+ days)"
   - Click "📧 Email Inactive" → Done!

3. **Lieutenant vs Captain breakdown:**
   - Filter: Exam Type = "Lieutenant"
   - Export CSV → See who's prepping for Lt. exam

4. **Clean up test accounts:**
   - Filter: Performance = "No Sessions"
   - Select all → Bulk Delete

5. **Update department info:**
   - Search for student by name
   - Click "Edit" → Update department → Save

---

## 🐛 Troubleshooting

**Emails not sending?**
- Check `RESEND_API_KEY` in environment variables
- Verify Resend account is active
- Check Vercel logs for errors

**Export button not working?**
- Check browser console for errors
- Make sure browser allows downloads
- Try a different browser

**Filters not working?**
- Hard refresh (Cmd+Shift+R)
- Check for console errors
- Verify `last_sign_in_at` column exists in profiles table

**Edit/Delete not working?**
- Verify you're logged in as admin
- Check API route exists at correct path
- Check Vercel deployment logs

---

## ✅ Testing Checklist

After deployment, test each feature:

- [ ] Search by student name
- [ ] Search by email
- [ ] Search by department
- [ ] Filter by exam type
- [ ] Filter by activity level
- [ ] Filter by performance
- [ ] Export CSV (check file downloads)
- [ ] Click student name (detail modal opens)
- [ ] Close detail modal
- [ ] Click Edit button (edit modal opens)
- [ ] Update student info and save
- [ ] Select one student
- [ ] Select multiple students
- [ ] Bulk delete
- [ ] Email inactive students
- [ ] Clear all filters
- [ ] Delete single student (existing feature)

---

## 🎉 You're Done!

All 6 features are now live on your Students page. Your admin experience just got 10x better! 🔥

**Questions?** Test each feature and let me know if you hit any issues!
